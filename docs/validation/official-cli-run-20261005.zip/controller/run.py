"""Fresh public clones and unmodified official isolated CLI, with scoped logs."""
import hashlib,json,subprocess,time,uuid
from datetime import datetime,timezone
from pathlib import Path

context=Path(__file__).parent
workspace=Path('C:/Users/Carlos IA/pocketful-official-validation-20261005')
if workspace.exists():raise SystemExit('Fresh validation workspace already exists; do not overwrite')
workspace.mkdir()
output=workspace/'output';output.mkdir()
run_id=uuid.uuid4().hex[:12]
image='pocketful-validation-controller:20261005-git-'+run_id
container='pocketful-official-cli-20261005-'+run_id
receipt={'kind':'independent_official_cli_attempt','started_at':datetime.now(timezone.utc).isoformat(),'state':'preparing','container':container,'controller_image':image,'workspace':str(workspace),'harness_revision':'803560d2a678ace1414465c098eb0ab5380ffade','result_revision':'b493eb4','commands':[],'harness_modified':False,'new_band_run':False,'agents_started':False}
def save():
    (output/'controller-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
def run(args,name,timeout=300,cwd=None):
    print('START '+name,flush=True)
    receipt['commands'].append({'argv':args,'log':name+'.log','state':'running'});save()
    with (output/(name+'.log')).open('wb') as log:
        code=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=timeout,cwd=cwd).returncode
    receipt['commands'][-1].update(state='completed',exit_code=code);save()
    print('END '+name+' exit='+str(code),flush=True)
    if code:raise RuntimeError(name+' failed; inspect its preserved log')
def linux(path):
    resolved=path.resolve().as_posix()
    if not resolved.startswith('C:/Users/Carlos IA/'):raise ValueError('Unexpected host path')
    return '/run/desktop/mnt/host/c/'+resolved[3:]
try:
    run(['docker','build','-t',image,'-f',str(context/'Dockerfile'),str(context)],'controller-build',300)
    harness=workspace/'harness';result=workspace/'result'
    run(['git','-c','credential.helper=','clone','--no-checkout','https://github.com/band-ai/dark-factory-wearedevs.git',str(harness)],'harness-clone')
    run(['git','-C',str(harness),'config','core.autocrlf','true'],'harness-checkout-policy')
    run(['git','-C',str(harness),'checkout','--detach',receipt['harness_revision']],'harness-checkout')
    run(['git','-c','credential.helper=','clone','--branch','codex/evidence-review-20261004','--no-checkout','https://github.com/jazzautomations/pocketful-dark-factory.git',str(result)],'result-clone')
    run(['git','-C',str(result),'config','core.autocrlf','false'],'result-checkout-policy')
    run(['git','-C',str(result),'checkout','--detach','b493eb4'],'result-checkout')
    for repo in (harness,result):
        if subprocess.check_output(['git','-C',str(repo),'status','--porcelain']).strip():raise ValueError('Clone is not clean')
    if subprocess.check_output(['git','-C',str(result),'diff','1042011','HEAD','--name-only','--','stage-1','stage-2','stage-3','stage-4','room.json','mandates']).strip():raise ValueError('Frozen source changed')
    receipt['result_revision']=subprocess.check_output(['git','-C',str(result),'rev-parse','HEAD']).decode().strip()
    receipt['source_room_sha256']=hashlib.sha256((result/'room.json').read_bytes()).hexdigest()
    receipt['harness_checkout_policy']='core.autocrlf=true, clean Git tree; normal Windows checkout endings retained for runner cache'
    receipt['result_checkout_policy']='core.autocrlf=false, clean Git tree'
    receipt['state']='running';save()
    h,r,o=map(linux,(harness,result,output))
    common=['docker','run','--rm','--network','none','--label','pocketful.validation=official-cli-20261005','--mount','type=bind,source=/var/run/docker.sock,target=/var/run/docker.sock']
    for src,dst,readonly in [(harness,h,True),(result,r,True),(output,o,False)]:
        common.extend(['--mount','type=bind,source='+src.as_posix()+',target='+dst+(',readonly' if readonly else '')])
    common.extend(['--workdir',h])
    run(common+['--name',container+'-check',image,'python','-m','harness','check',r,'--track','pocketful'],'official-check',120)
    args=common+['--name',container,image,'python','-m','harness','run','--track','pocketful','--repo',r,'--all','--mode','isolated','--out',o+'/official-all']
    run(args,'official-all',3600)
    receipt['state']='completed'
except Exception as exc:
    receipt['state']='failed';receipt['reason']=str(exc)
    print('FAIL '+str(exc),flush=True)
finally:
    receipt['finished_at']=datetime.now(timezone.utc).isoformat();save()
print(json.dumps({'state':receipt['state'],'workspace':str(workspace),'container':container}),flush=True)
raise SystemExit(0 if receipt['state']=='completed' else 1)
