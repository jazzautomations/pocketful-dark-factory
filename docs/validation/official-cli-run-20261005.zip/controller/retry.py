import json,subprocess,uuid
from pathlib import Path
from datetime import datetime,timezone
root=Path('C:/Users/Carlos IA/pocketful-official-validation-20261005')
output=root/'output'
previous=json.loads((output/'controller-receipt.json').read_text())
assert previous['state']=='failed'
entry=next(row for row in previous['commands'] if row['log']=='official-all.log')
args=list(entry['argv']);assert args[args.index('--network')+1]=='none'
args[args.index('--network')+1]='bridge'
container='pocketful-official-cli-retry-20261005-'+uuid.uuid4().hex[:12]
args[args.index('--name')+1]=container
args[args.index('--out')+1]=args[args.index('--out')+1]+'-v2'
assert not (output/'official-all-v2').exists()
for name in ('harness','result'):
    assert not subprocess.check_output(['git','-C',str(root/name),'status','--porcelain']).strip()
receipt={'kind':'independent_official_cli_attempt','started_at':datetime.now(timezone.utc).isoformat(),'state':'running','container':container,'previous_attempt':'controller-receipt.json','only_configuration_change':'controller build-client network bridge; test services remain official isolated mode/internal networks','harness_revision':previous['harness_revision'],'result_revision':previous['result_revision'],'source_room_sha256':previous['source_room_sha256'],'command':args,'harness_modified':False,'new_band_run':False,'agents_started':False}
def save():
    (output/'controller-receipt-v2.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
save();print('START official-all-v2 '+container,flush=True)
try:
    with (output/'official-all-v2.log').open('wb') as log:
        code=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=3600).returncode
    receipt.update(state='completed' if code==0 else 'failed',exit_code=code)
except Exception as exc:
    receipt.update(state='observation_error',reason=str(exc))
finally:
    receipt['finished_at']=datetime.now(timezone.utc).isoformat();save()
print(json.dumps({'state':receipt['state'],'exit_code':receipt.get('exit_code'),'container':container}),flush=True)
raise SystemExit(0 if receipt['state']=='completed' else 1)
