"""Supplementary black-box history attacks derived from pinned stage-3/4 specs.

Not a full clause matrix or official hidden suite. Only disposable fixture services.
Authority: pocketful/spec/stage-3.md and stage-4.md at 803560d2.
"""
import concurrent.futures
from datetime import datetime, timedelta, timezone
import threading

import pytest
from test_spec_attack import api, login, pay, key, err, settle


def instant(value):
    return datetime.fromisoformat(value.replace('Z', '+00:00'))


def stamp(value):
    return value.isoformat()


def accounts(api):
    return [login(api, name + '@x.com') for name in ('ada', 'bob', 'cy')]


def payment(api, auth, recipient='bob', amount=100, visibility='private'):
    r = pay(api, auth, {'to_handle': recipient, 'amount': amount, 'visibility': visibility}, key())
    assert r.status_code == 201, r.text
    return r.json()


def correction(api, auth, p, amount, expected=1, k=None, effective=None):
    return api.post('/payments/' + p['payment_id'] + '/corrections',
        headers={**auth, 'Idempotency-Key': k or key()}, json={
            'expected_revision': expected, 'amount': amount,
            'effective_at': effective or p['created_at'], 'reason': 'independent probe'})


def revisions(api, auth, p):
    r = api.get('/payments/' + p['payment_id'] + '/revisions', headers=auth)
    assert r.status_code == 200, r.text
    return r.json()['revisions']


def batch_item(p, amount, expected=1, effective=None):
    return {'payment_id': p['payment_id'], 'expected_revision': expected,
        'amount': amount, 'effective_at': effective or p['created_at'], 'reason': 'independent batch probe'}


def batch(api, auth, items, k=None):
    return api.post('/correction-batches', headers={**auth, 'Idempotency-Key': k or key()}, json={'corrections': items})


def assert_total(api, auths, expected=3000):
    balances = [api.get('/me', headers=auth).json()['balance'] for auth in auths]
    assert sum(balances) == expected, balances


# Stage 3: GET /me inclusive boundary and effective versus recorded time.
def test_as_of_inclusive_and_known_at_excludes_not_yet_recorded_payment(api):
    ada, bob, cy = accounts(api)
    p = payment(api, ada)
    t = instant(p['created_at'])
    for when, balance in [(t - timedelta(microseconds=1), 1000), (t, 900)]:
        r = api.get('/me', headers=ada, params={'as_of': stamp(when)})
        assert r.status_code == 200, r.text
        assert r.json()['balance'] == balance
        assert r.json()['as_of'] == stamp(when)
    r = api.get('/me', headers=ada, params={'as_of': stamp(t + timedelta(days=1)), 'known_at': stamp(t - timedelta(microseconds=1))})
    assert r.status_code == 200, r.text
    assert r.json()['balance'] == 1000


@pytest.mark.parametrize('param', ['as_of', 'known_at'])
@pytest.mark.parametrize('bad', ['', '2026-10-05', '2026-10-05T12:00:00'])
def test_temporal_instants_require_offset_and_nonempty_value(api, param, bad):
    ada = login(api, 'ada@x.com')
    r = api.get('/me', headers=ada, params={param: bad})
    assert (r.status_code, err(r)) == (422, 'validation_failed'), r.text


# Stage 3: half-open statement boundary, full-window balances and pagination.
def test_statement_window_is_half_open_and_page_balances_are_full_window(api):
    ada, bob, cy = accounts(api)
    first = payment(api, ada)
    second = payment(api, ada, 'cy', 75)
    t = instant(first['created_at'])
    r = api.get('/statement', headers=ada, params={'from': stamp(t - timedelta(seconds=1)), 'to': first['created_at']})
    assert r.status_code == 200, r.text
    assert r.json()['entries'] == []
    assert r.json()['opening_balance'] == r.json()['closing_balance'] == 1000
    r = api.get('/statement', headers=ada, params={'from': first['created_at'], 'to': stamp(instant(second['created_at']) + timedelta(seconds=1)), 'limit': 1})
    assert r.status_code == 200, r.text
    first_page = r.json()
    assert first_page['opening_balance'] == 1000 and first_page['closing_balance'] == 825
    assert first_page['has_more'] is True
    r = api.get('/statement', headers=ada, params={'snapshot': first_page['snapshot'], 'limit': 1, 'offset': 2})
    assert r.status_code == 200, r.text
    last = r.json()
    assert last['entries'] == [] and last['has_more'] is False
    assert (last['opening_balance'], last['closing_balance']) == (1000, 825)


# Stage 3: saved statements, zero revisions, receipt and known_at immutability.
def test_zero_correction_preserves_snapshot_receipt_and_original_known_view(api):
    ada, bob, cy = accounts(api)
    k = key()
    body = {'to_handle': 'bob', 'amount': 100}
    original = pay(api, ada, body, k)
    assert original.status_code == 201
    p = original.json()
    saved = api.get('/statement', headers=ada).json()
    r = correction(api, ada, p, 0)
    assert r.status_code == 201, r.text
    fresh = api.get('/statement', headers=ada).json()
    assert len(fresh['entries']) == 1 and fresh['entries'][0]['delta'] == 0
    assert fresh['entries'][0]['revision'] == 2
    assert fresh['entries'][0]['payment']['amount'] == 0
    old = api.get('/statement', headers=ada, params={'snapshot': saved['snapshot']})
    assert old.status_code == 200, old.text
    for field in ['entries', 'opening_balance', 'closing_balance', 'has_more']:
        assert old.json()[field] == saved[field]
    replay = pay(api, ada, body, k)
    assert replay.status_code == 200 and replay.json() == p
    prior = api.get('/me', headers=ada, params={'known_at': p['created_at']})
    assert prior.status_code == 200 and prior.json()['balance'] == 900
    assert_total(api, [ada, bob, cy])


@pytest.mark.parametrize('extra', ['from', 'to', 'known_at'])
def test_saved_statement_disallows_temporal_parameters_even_empty(api, extra):
    ada = login(api, 'ada@x.com')
    token = api.get('/statement', headers=ada).json()['snapshot']
    r = api.get('/statement', headers=ada, params={'snapshot': token, extra: ''})
    assert (r.status_code, err(r)) == (422, 'validation_failed'), r.text


def test_public_payment_does_not_expose_private_revisions_or_third_party_statement(api):
    ada, bob, cy = accounts(api)
    p = payment(api, ada, visibility='public')
    r = api.get('/payments/' + p['payment_id'] + '/revisions', headers=cy)
    assert (r.status_code, err(r)) == (404, 'not_found'), r.text
    r = api.get('/payments/' + p['payment_id'] + '/revisions')
    assert (r.status_code, err(r)) == (401, 'unauthenticated'), r.text
    assert revisions(api, bob, p)[0]['reason'] == ''
    assert api.get('/statement', headers=cy).json()['entries'] == []


# Stage 3 Historical holds: known creation implies known future expiry.
def test_historical_hold_creation_and_future_expiry_share_one_view(api):
    ada, bob, cy = accounts(api)
    r = api.post('/authorizations', headers={**ada, 'Idempotency-Key': key()}, json={'to_handle': 'bob', 'amount': 200})
    assert r.status_code == 201, r.text
    hold = r.json()
    for when, held in [(hold['created_at'], 200), (hold['expires_at'], 0)]:
        view = api.get('/me', headers=ada, params={'as_of': when, 'known_at': hold['created_at']})
        assert view.status_code == 200, view.text
        assert (view.json()['balance'], view.json()['total'], view.json()['held'], view.json()['available']) == (1000, 1000, held, 1000-held)
    assert api.get('/statement', headers=ada).json()['entries'] == []


def test_historical_available_overdraft_rejects_without_consuming_key(api):
    ada, bob, cy = accounts(api)
    r = api.post('/authorizations', headers={**ada, 'Idempotency-Key': key()}, json={'to_handle': 'bob', 'amount': 900})
    assert r.status_code == 201, r.text
    hold = r.json()
    p = payment(api, ada, 'cy', 100)
    r = api.post('/authorizations/' + hold['authorization_id'] + '/void', headers=ada, json={})
    assert r.status_code == 200, r.text
    k = key()
    r = correction(api, ada, p, 200, k=k)
    assert (r.status_code, err(r)) == (409, 'historical_overdraft'), r.text
    assert len(revisions(api, ada, p)) == 1
    assert api.get('/me', headers=ada).json()['balance'] == 900
    r = correction(api, ada, p, 50, k=k)
    assert r.status_code == 201, r.text
    assert_total(api, [ada, bob, cy])


# Stage 3 concurrency: overlapping expected revision cannot both commit.
def test_concurrent_corrections_commit_once_and_loser_key_remains_reusable(api):
    ada, bob, cy = accounts(api)
    p = payment(api, ada)
    keys = [key(), key()]
    barrier = threading.Barrier(2)
    def submit(i):
        barrier.wait(timeout=10)
        return correction(api, ada, p, 200 + 100*i, k=keys[i])
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(submit, range(2)))
    assert sorted(r.status_code for r in results) == [201, 409], [r.text for r in results]
    loser = next(i for i,r in enumerate(results) if r.status_code == 409)
    assert err(results[loser]) == 'stale_revision'
    history = revisions(api, ada, p)
    assert len(history) == 2 and instant(history[1]['recorded_at']) > instant(history[0]['recorded_at'])
    r = correction(api, ada, p, 400, expected=2, k=keys[loser])
    assert r.status_code == 201, r.text
    assert_total(api, [ada, bob, cy])


# Stage 4 batch corrections: combined affordability and equality of instants.
def test_batch_net_effect_affordability_without_intermediate_debits(api):
    ada, bob, cy = accounts(api)
    p1 = payment(api, ada, 'bob')
    p2 = payment(api, bob, 'ada')
    payment(api, ada, 'cy', 1000)
    payment(api, bob, 'cy', 1000)
    t = p1['created_at']
    r = batch(api, ada, [batch_item(p1,0,effective=t),batch_item(p2,0,effective=t)])
    assert r.status_code == 201, r.text
    assert api.get('/me', headers=ada).json()['available'] == 0
    assert api.get('/me', headers=bob).json()['available'] == 0
    assert_total(api, [ada, bob, cy])


def test_complete_settlement_batch_accepts_equal_instants_with_distinct_offsets(api):
    ada, bob, cy = accounts(api)
    r = settle(api, ada, [{'from_handle':'ada','to_handle':'bob','amount':100},{'from_handle':'bob','to_handle':'cy','amount':50}], key())
    assert r.status_code == 201, r.text
    saved = r.json()
    p1,p2 = saved['payments']
    utc = p1['created_at']
    other = stamp(instant(utc).astimezone(timezone(timedelta(hours=2))))
    r = batch(api, ada, [batch_item(p1,90,effective=utc),batch_item(p2,40,effective=other)])
    assert r.status_code == 201, r.text
    body = r.json()
    assert [r['payment_id'] for r in body['revisions']] == [p1['payment_id'],p2['payment_id']]
    assert {r['recorded_at'] for r in body['revisions']} == {body['recorded_at']}
    assert instant(body['recorded_at']) > max(instant(p['created_at']) for p in [p1,p2])
    assert all(r['correction_batch_id'] == body['correction_batch_id'] for r in body['revisions'])
    assert_total(api,[ada,bob,cy])


def test_overlapping_batches_commit_once_with_no_loser_partial_history(api):
    ada,bob,cy = accounts(api)
    payments=[payment(api,ada,'bob'),payment(api,ada,'cy'),payment(api,ada,'bob')]
    bodies=[[batch_item(payments[0],90),batch_item(payments[1],90)],[batch_item(payments[0],80),batch_item(payments[2],80)]]
    barrier=threading.Barrier(2)
    def submit(i):
        barrier.wait(timeout=10)
        return batch(api,ada,bodies[i])
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        results=list(pool.map(submit,range(2)))
    assert sorted(r.status_code for r in results)==[201,409],[r.text for r in results]
    winner=next(i for i,r in enumerate(results) if r.status_code==201)
    loser=1-winner
    assert err(results[loser])=='stale_revision'
    assert len(revisions(api,ada,payments[0]))==2
    assert len(revisions(api,ada,payments[winner+1]))==2
    assert len(revisions(api,ada,payments[loser+1]))==1
    assert api.get('/me',headers=ada).json()['balance']==(720 if winner==0 else 740)
    assert_total(api,[ada,bob,cy])


# Stage 4 refunds: held funds unavailable; failed key reusable after release.
def test_refund_uses_available_funds_and_failed_key_is_not_consumed(api):
    ada,bob,cy=accounts(api)
    p=payment(api,ada)
    r=api.post('/authorizations',headers={**bob,'Idempotency-Key':key()},json={'to_handle':'cy','amount':1100})
    assert r.status_code==201,r.text
    hold=r.json();k=key();url='/payments/'+p['payment_id']+'/refunds'
    r=api.post(url,headers={**bob,'Idempotency-Key':k},json={'amount':100})
    assert (r.status_code,err(r))==(409,'insufficient_funds'),r.text
    assert api.post('/authorizations/'+hold['authorization_id']+'/void',headers=bob,json={}).status_code==200
    r=api.post(url,headers={**bob,'Idempotency-Key':k},json={'amount':100})
    assert r.status_code==201,r.text
    assert_total(api,[ada,bob,cy])


@pytest.mark.parametrize('same_key',[True,False])
def test_concurrent_refunds_respect_key_and_cumulative_corrected_amount(api,same_key):
    ada,bob,cy=accounts(api)
    p=payment(api,ada);shared=key();barrier=threading.Barrier(8)
    def submit(i):
        barrier.wait(timeout=10)
        return api.post('/payments/'+p['payment_id']+'/refunds',headers={**bob,'Idempotency-Key':shared if same_key else key()},json={'amount':60})
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        results=list(pool.map(submit,range(8)))
    assert sum(r.status_code==201 for r in results)==1,[r.text for r in results]
    if same_key:
        assert all(r.status_code in (200,201) for r in results)
        assert all(r.json()==results[0].json() for r in results)
    else:
        assert all(r.status_code in (201,422) for r in results)
        assert all(err(r)=='refund_exceeds_payment' for r in results if r.status_code==422)
    assert api.get('/me',headers=ada).json()['balance']==960
    assert api.get('/me',headers=bob).json()['balance']==1040
    assert_total(api,[ada,bob,cy])
