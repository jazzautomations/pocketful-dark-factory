"""Black-box spec attack: BDD scenarios derived from the official contract's
fine print — the rules the shipped public checks never exercise. Judges run a
larger hidden suite and score "what the shipped checks never asked", so every
scenario here cites the spec rule it enforces. Run against a live service:

    BASE=http://127.0.0.1:8080 python -m pytest tools/spec-attack -q

Requires httpx + pytest (the official harness venv has both). Destructive:
uses /_test/reset. Never point it at anything you care about.
"""
import concurrent.futures
import os
import uuid

import httpx
import pytest

BASE = os.environ.get("BASE", "http://127.0.0.1:8080")


def client():
    return httpx.Client(base_url=BASE, timeout=10.0)


def key():
    return uuid.uuid4().hex


@pytest.fixture()
def api():
    with client() as c:
        r = c.post("/_test/reset", json={
            "currency": "USD", "minor_units": 2,
            "users": [
                {"id": "u_ada", "email": "ada@x.com", "password": "password123",
                 "display_name": "Ada", "handle": "ada", "balance": 1000},
                {"id": "u_bob", "email": "bob@x.com", "password": "password123",
                 "display_name": "Bob", "handle": "bob", "balance": 1000},
                {"id": "u_cy", "email": "cy@x.com", "password": "password123",
                 "display_name": "Cy", "handle": "cy", "balance": 1000},
            ],
            "settlement_operator_ids": ["u_ada"]})
        assert r.status_code in (200, 204), r.text
        yield c


def login(c, email):
    r = c.post("/auth/login", json={"email": email, "password": "password123"})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['token']}"}


def pay(c, auth, body, k):
    return c.post("/payments", headers={**auth, "Idempotency-Key": k}, json=body)


def err(resp):
    return resp.json()["error"]["code"]


# --- Idempotency fine print (stage 1 §5) -----------------------------------

def test_given_claimed_key_when_replayed_with_invalid_different_body_then_reuse_wins(api):
    # "an already claimed key is resolved before endpoint field validation"
    ada = login(api, "ada@x.com")
    k = key()
    assert pay(api, ada, {"to_handle": "bob", "amount": 100}, k).status_code == 201
    r = pay(api, ada, {"to_handle": "bob", "amount": -5}, k)
    assert (r.status_code, err(r)) == (409, "idempotency_key_reuse"), r.text


def test_given_claimed_key_when_resource_state_changed_then_replay_returns_original(api):
    ada, bob = login(api, "ada@x.com"), login(api, "bob@x.com")
    k = key()
    first = pay(api, ada, {"to_handle": "bob", "amount": 100}, k)
    assert first.status_code == 201
    # Burn the rest of ada's funds so the same request could no longer succeed.
    assert pay(api, ada, {"to_handle": "bob", "amount": 900}, key()).status_code == 201
    replay = pay(api, ada, {"to_handle": "bob", "amount": 100}, k)
    assert replay.status_code == 200
    assert replay.json() == first.json(), "replay body must be the original as a JSON value"


def test_given_same_key_and_body_when_sent_on_other_path_then_it_is_a_fresh_request(api):
    # "same key with the same body on a different path is a different request"
    ada = login(api, "ada@x.com")
    k = key()
    assert pay(api, ada, {"to_handle": "bob", "amount": 100}, k).status_code == 201
    r = api.post("/requests", headers={**ada, "Idempotency-Key": k},
                 json={"payer_handle": "bob", "amount": 100})
    assert r.status_code == 201, r.text


def test_given_key_whose_first_use_failed_4xx_then_key_is_reusable_as_first_use(api):
    ada = login(api, "ada@x.com")
    k = key()
    assert pay(api, ada, {"to_handle": "bob", "amount": 10**9 + 1}, k).status_code == 422
    assert pay(api, ada, {"to_handle": "nobody", "amount": 100}, k).status_code == 404
    assert pay(api, ada, {"to_handle": "bob", "amount": 100}, k).status_code == 201


def test_given_key_order_and_whitespace_differences_then_same_json_value_is_a_replay(api):
    ada = login(api, "ada@x.com")
    k = key()
    h = {**ada, "Idempotency-Key": k, "Content-Type": "application/json"}
    r1 = api.post("/payments", headers=h, content=b'{"to_handle":"bob","amount":100}')
    assert r1.status_code == 201
    r2 = api.post("/payments", headers=h, content=b'{ "amount" : 100, "to_handle" : "bob" }')
    assert r2.status_code == 200 and r2.json() == r1.json(), r2.text


def test_given_empty_and_oversized_idempotency_keys_then_400_and_422(api):
    ada = login(api, "ada@x.com")
    r = api.post("/payments", headers={**ada, "Idempotency-Key": ""},
                 json={"to_handle": "bob", "amount": 100})
    assert (r.status_code, err(r)) == (400, "missing_idempotency_key")
    r = api.post("/payments", headers={**ada, "Idempotency-Key": "k" * 256},
                 json={"to_handle": "bob", "amount": 100})
    assert (r.status_code, err(r)) == (422, "validation_failed")


def test_given_one_unused_key_when_hammered_concurrently_then_exactly_one_201(api):
    # "For concurrent identical requests with an unused key, exactly one returns 201."
    ada = login(api, "ada@x.com")
    k = key()
    body = {"to_handle": "bob", "amount": 50}

    def fire(_):
        with client() as c:
            r = pay(c, ada, body, k)
            return r.status_code, r.text

    with concurrent.futures.ThreadPoolExecutor(max_workers=16) as ex:
        results = list(ex.map(fire, range(16)))
    codes = [s for s, _ in results]
    assert codes.count(201) == 1 and codes.count(200) == 15, codes
    bodies = {t for s, t in results}
    assert len({httpx.Response(200, text=b).json()["payment_id"] for b in
                (t for _, t in results)}) == 1, bodies


# --- Validation fine print (stage 1 §3) ------------------------------------

@pytest.mark.parametrize("amount,code,ecode", [
    ("100", 422, "validation_failed"),      # string amount: endpoint rule wins over 400
    (True, 422, "validation_failed"),       # boolean amount
    (0, 422, "validation_failed"),          # below 1
    (10**9 + 1, 422, "validation_failed"),  # above max
    (99.5, 422, "validation_failed"),       # not an integer
])
def test_given_invalid_amounts_then_422_validation_failed(api, amount, code, ecode):
    ada = login(api, "ada@x.com")
    r = pay(api, ada, {"to_handle": "bob", "amount": amount}, key())
    assert (r.status_code, err(r)) == (code, ecode), (amount, r.text)


def test_given_null_note_then_422_but_wrong_type_elsewhere_is_400(api):
    ada = login(api, "ada@x.com")
    r = pay(api, ada, {"to_handle": "bob", "amount": 100, "note": None}, key())
    assert (r.status_code, err(r)) == (422, "validation_failed"), r.text
    r = pay(api, ada, {"to_handle": 7, "amount": 100}, key())
    assert (r.status_code, err(r)) == (400, "malformed_request"), r.text


def test_given_note_at_and_over_200_chars_then_boundary_is_exact(api):
    ada = login(api, "ada@x.com")
    assert pay(api, ada, {"to_handle": "bob", "amount": 1, "note": "x" * 200},
               key()).status_code == 201
    r = pay(api, ada, {"to_handle": "bob", "amount": 1, "note": "x" * 201}, key())
    assert (r.status_code, err(r)) == (422, "validation_failed")


@pytest.mark.parametrize("limit", ["+4", "4.0", "1e9", "201", "0", "-1"])
def test_given_nonplain_or_out_of_range_limit_then_422(api, limit):
    # Integer query params are plain decimal digits; 1 to 200.
    ada = login(api, "ada@x.com")
    r = api.get(f"/activity?limit={limit}", headers=ada)
    assert (r.status_code, err(r)) == (422, "validation_failed"), (limit, r.text)


def test_given_unparseable_body_then_400_malformed_request(api):
    ada = login(api, "ada@x.com")
    r = api.post("/payments", headers={**ada, "Idempotency-Key": key(),
                                       "Content-Type": "application/json"},
                 content=b'{"to_handle": "bob", ')
    assert (r.status_code, err(r)) == (400, "malformed_request")


def test_given_unknown_fields_then_they_are_ignored(api):
    ada = login(api, "ada@x.com")
    r = pay(api, ada, {"to_handle": "bob", "amount": 100, "wire_to": "cayman"}, key())
    assert r.status_code == 201, r.text


# --- Splits (stage 1 §8) ---------------------------------------------------

def test_given_1000_split_3_ways_then_larger_shares_go_first(api):
    ada = login(api, "ada@x.com")
    r = api.post("/splits", headers={**ada, "Idempotency-Key": key()},
                 json={"amount": 1000, "participant_handles": ["bob", "cy", "ada"]})
    assert r.status_code == 201, r.text
    shares = [s["amount"] for s in r.json()["shares"]]
    assert shares == [334, 333, 333], shares


def test_given_duplicate_participant_then_422(api):
    ada = login(api, "ada@x.com")
    r = api.post("/splits", headers={**ada, "Idempotency-Key": key()},
                 json={"amount": 900, "participant_handles": ["bob", "bob"]})
    assert (r.status_code, err(r)) == (422, "validation_failed")


# --- Settlements (stage 1 §9) ----------------------------------------------

def settle(c, auth, transfers, k):
    return c.post("/settlements", headers={**auth, "Idempotency-Key": k},
                  json={"transfers": transfers})


def test_given_entry_error_and_insufficient_funds_then_entry_error_wins_in_order(api):
    # "Entry errors take precedence in input order, before insufficient funds."
    ada = login(api, "ada@x.com")
    r = settle(api, ada, [
        {"from_handle": "ada", "to_handle": "bob", "amount": 10**12},   # entry error (range)
        {"from_handle": "ghost", "to_handle": "bob", "amount": 50},     # would be 404
    ], key())
    assert (r.status_code, err(r)) == (422, "validation_failed"), r.text
    r = settle(api, ada, [
        {"from_handle": "ghost", "to_handle": "bob", "amount": 50},     # 404 first in order
        {"from_handle": "ada", "to_handle": "bob", "amount": 10**12},
    ], key())
    assert (r.status_code, err(r)) == (404, "not_found"), r.text


def test_given_collectively_unaffordable_settlement_then_atomic_409_and_no_state(api):
    ada = login(api, "ada@x.com")
    before = api.get("/me", headers=ada).json()["balance"]
    k = key()
    r = settle(api, ada, [
        {"from_handle": "ada", "to_handle": "bob", "amount": 900},
        {"from_handle": "ada", "to_handle": "cy", "amount": 900},
    ], k)
    assert (r.status_code, err(r)) == (409, "insufficient_funds")
    assert api.get("/me", headers=ada).json()["balance"] == before
    # "failed validation claims no idempotency key"
    r = settle(api, ada, [{"from_handle": "ada", "to_handle": "bob", "amount": 10}], k)
    assert r.status_code == 201, r.text


def test_given_committed_settlement_then_members_share_created_at_equal_committed_at(api):
    ada = login(api, "ada@x.com")
    r = settle(api, ada, [
        {"from_handle": "ada", "to_handle": "bob", "amount": 10},
        {"from_handle": "bob", "to_handle": "cy", "amount": 5},
    ], key())
    assert r.status_code == 201, r.text
    body = r.json()
    stamps = {p["created_at"] for p in body["payments"]}
    assert stamps == {body["committed_at"]}, body
    assert all(p["settlement_id"] == body["settlement_id"] for p in body["payments"])
    nonmember = pay(api, ada, {"to_handle": "bob", "amount": 1}, key()).json()
    assert nonmember["settlement_id"] is None


# --- Auth fine print -------------------------------------------------------

def test_given_signup_then_handle_is_derived_and_collision_creates_nothing(api):
    r = api.post("/auth/signup", json={"email": "zed@x.com",
                                       "password": "password123",
                                       "display_name": "Zed"})
    assert r.status_code == 201, r.text
    r2 = api.post("/auth/signup", json={"email": "zed@y.com",
                                        "password": "password123",
                                        "display_name": "Zed Two"})
    assert (r2.status_code, err(r2)) == (409, "handle_taken"), r2.text
    r3 = api.post("/auth/login", json={"email": "zed@y.com", "password": "password123"})
    assert r3.status_code == 401, "no account may exist after handle collision"


def test_given_malformed_bearer_then_401_unauthenticated(api):
    for header in ({"Authorization": "Bearer"}, {"Authorization": "Token abc"},
                   {"Authorization": "Bearer tok_doesnotexist"}, {}):
        r = api.get("/me", headers=header)
        assert (r.status_code, err(r)) == (401, "unauthenticated"), header


# --- Stage 4 fine print: refunds and batch corrections ---------------------

def test_given_refunds_summing_past_corrected_amount_then_422_refund_exceeds(api):
    ada, bob = login(api, "ada@x.com"), login(api, "bob@x.com")
    p = pay(api, ada, {"to_handle": "bob", "amount": 100}, key()).json()["payment_id"]
    rf = api.post(f"/payments/{p}/refunds", headers={**bob, "Idempotency-Key": key()},
                  json={"amount": 60})
    assert rf.status_code == 201, rf.text
    r = api.post(f"/payments/{p}/refunds", headers={**bob, "Idempotency-Key": key()},
                 json={"amount": 41})
    assert (r.status_code, err(r)) == (422, "refund_exceeds_payment"), r.text
    assert api.post(f"/payments/{p}/refunds", headers={**bob, "Idempotency-Key": key()},
                    json={"amount": 40}).status_code == 201


def test_given_refund_of_a_refund_then_invalid_refund_target(api):
    ada, bob = login(api, "ada@x.com"), login(api, "bob@x.com")
    p = pay(api, ada, {"to_handle": "bob", "amount": 100}, key()).json()["payment_id"]
    refund = api.post(f"/payments/{p}/refunds", headers={**bob, "Idempotency-Key": key()},
                      json={"amount": 50}).json()["payment_id"]
    r = api.post(f"/payments/{refund}/refunds", headers={**ada, "Idempotency-Key": key()},
                 json={"amount": 10})
    assert (r.status_code, err(r)) == (422, "invalid_refund_target"), r.text


def test_given_correction_below_refunded_amount_then_422_refund_exceeds(api):
    ada, bob = login(api, "ada@x.com"), login(api, "bob@x.com")
    p = pay(api, ada, {"to_handle": "bob", "amount": 100}, key()).json()["payment_id"]
    assert api.post(f"/payments/{p}/refunds", headers={**bob, "Idempotency-Key": key()},
                    json={"amount": 60}).status_code == 201
    r = api.post(f"/payments/{p}/corrections", headers={**ada, "Idempotency-Key": key()},
                 json={"expected_revision": 1, "amount": 50,
                       "effective_at": "2026-09-01T10:00:00+00:00", "reason": "shrink"})
    assert (r.status_code, err(r)) == (422, "refund_exceeds_payment"), r.text


def test_given_batch_with_stale_revision_then_409_and_nothing_changes(api):
    # Rejected batch leaves history, balances and idempotency records unchanged.
    ada = login(api, "ada@x.com")
    p1 = pay(api, ada, {"to_handle": "bob", "amount": 100}, key()).json()["payment_id"]
    p2 = pay(api, ada, {"to_handle": "cy", "amount": 100}, key()).json()["payment_id"]
    before = api.get("/me", headers=ada).json()["balance"]
    k = key()
    r = api.post("/correction-batches", headers={**ada, "Idempotency-Key": k},
                 json={"corrections": [
                     {"payment_id": p1, "expected_revision": 1, "amount": 90,
                      "effective_at": "2026-09-01T10:00:00+00:00", "reason": "a"},
                     {"payment_id": p2, "expected_revision": 7, "amount": 90,
                      "effective_at": "2026-09-01T10:00:00+00:00", "reason": "b"},
                 ]})
    assert (r.status_code, err(r)) == (409, "stale_revision"), r.text
    assert api.get("/me", headers=ada).json()["balance"] == before
    r = api.post("/correction-batches", headers={**ada, "Idempotency-Key": k},
                 json={"corrections": [
                     {"payment_id": p1, "expected_revision": 1, "amount": 90,
                      "effective_at": "2026-09-01T10:00:00+00:00", "reason": "a"},
                     {"payment_id": p2, "expected_revision": 1, "amount": 90,
                      "effective_at": "2026-09-01T10:00:00+00:00", "reason": "b"},
                 ]})
    assert r.status_code == 201, "failed batch must not claim the idempotency key"


def test_given_batch_with_duplicate_payment_ids_then_422(api):
    ada = login(api, "ada@x.com")
    p1 = pay(api, ada, {"to_handle": "bob", "amount": 100}, key()).json()["payment_id"]
    r = api.post("/correction-batches", headers={**ada, "Idempotency-Key": key()},
                 json={"corrections": [
                     {"payment_id": p1, "expected_revision": 1, "amount": 90,
                      "effective_at": "2026-09-01T10:00:00+00:00", "reason": "a"},
                     {"payment_id": p1, "expected_revision": 1, "amount": 80,
                      "effective_at": "2026-09-01T10:00:00+00:00", "reason": "b"},
                 ]})
    assert (r.status_code, err(r)) == (422, "validation_failed"), r.text


def test_given_future_effective_at_then_rejected(api):
    # "Effective times cannot be later than now."
    ada = login(api, "ada@x.com")
    p1 = pay(api, ada, {"to_handle": "bob", "amount": 100}, key()).json()["payment_id"]
    r = api.post(f"/payments/{p1}/corrections", headers={**ada, "Idempotency-Key": key()},
                 json={"expected_revision": 1, "amount": 90,
                       "effective_at": "2030-01-01T00:00:00+00:00", "reason": "later"})
    assert r.status_code == 422, r.text
